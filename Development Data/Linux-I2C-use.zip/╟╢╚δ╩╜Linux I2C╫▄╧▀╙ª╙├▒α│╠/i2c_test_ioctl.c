#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <string.h>

#define CHIP			"/dev/i2c-1"
#define CHIP_ADDR		0x40
#define OFS_ADDR		0x96

char wrdata[4] = {'4','3','2','1'};

int write_chip(int fd,char buff[],int addr,int count);
int read_chip(int fd,char buff[],int addr,int count);

int main(int argc,char *argv[])
{
	int ret,i;
	
	int addr = OFS_ADDR;
	unsigned char	rddata[8];

	int fd = open(CHIP, O_RDWR);
	if (fd < 0) 
	{
		printf("open failed\n");
		goto err0;
	}

	if (ioctl(fd, I2C_SLAVE_FORCE, CHIP_ADDR) < 0) 
	{		/* SLAVE ADDR */
		printf("ioctl:set slave address failed\n");
		goto err1;
	}
	
	memset(rddata,'\0',sizeof(rddata));
	ret = read_chip(fd,rddata,addr,4);
	if(ret < 0)
	{
		printf("read error ...\n");
		return -1;
	}
	printf("read origin(0x96~0x99) data is : ");
	for(i=0;i<ret;i++)
		printf("%x ",rddata[i]);
	printf("\n");

	usleep(10000);

	ret = write_chip(fd,&wrdata[0],addr,2);
	if(ret < 0)
	{
		printf("write error ...\n");
		return -1;
	}
	printf("write offset 0x96~0x97 is : %x %x \n",wrdata[0],wrdata[1]);

	usleep(10000);

	ret = write_chip(fd,&wrdata[2],addr+2,2);
	if(ret < 0)
	{
		printf("write error ...\n");
		return -1;
	}
	printf("write offset 0x98~0x99 is : %x %x \n",wrdata[2],wrdata[3]);

	usleep(10000);

	ret = read_chip(fd,rddata,addr,4);
	if(ret < 0)
	{
		printf("read error ...\n");
		return -1;
	}
	printf("read data(0x96~0x99) is : ");
	for(i=0;i<ret;i++)
		printf("%x ",rddata[i]);
	printf("\n");

err1:
	close(fd);
err0:
	return 0;
}

#define MAX_SIZE 8
int write_chip(int fd,char buff[],int addr,int count)
{
	int ret;
	struct i2c_rdwr_ioctl_data data;
	data.nmsgs = 1;					//开启信号数
	
	if((data.msgs = (struct i2c_msg*)malloc(data.nmsgs*sizeof(struct i2c_msg))) == NULL)
	{
		printf("malloc msgs error ...\n");
		ret = -1;
		goto err0;
	}
	if((data.msgs[0].buf = (unsigned char *)malloc((count + 1)*sizeof(char))) == NULL)
	{
		printf("malloc buf error ...\n");
		ret = -1;
		goto err1;
	}
	
	data.msgs[0].addr = CHIP_ADDR;	//从器件地址
	data.msgs[0].len  = count+1;	//数据长度
	data.msgs[0].flags = 0;			//操作方式:1读，0为写
	data.msgs[0].buf[0] = addr;		//寄存器偏移
	memcpy(&(data.msgs[0].buf[1]),buff,count);
	ret = ioctl(fd,I2C_RDWR,(unsigned long)&data);
	if(ret < 0)
	{
		printf("write error ...\n");
		goto err2;
	}
	
	return count;
err2:
	free(data.msgs[0].buf);
err1:	
	free(data.msgs);
err0:
	return ret;
}

int read_chip(int fd,char buff[],int addr,int count)
{
	int ret,i;
	struct i2c_rdwr_ioctl_data data;
	data.nmsgs = 2;					//开启信号数
	
	if((data.msgs = (struct i2c_msg*)malloc(data.nmsgs*sizeof(struct i2c_msg))) == NULL)
	{
		printf("malloc msgs error ...\n");
		ret = -1;
		goto err0;
	}
	
	if((data.msgs[0].buf = (unsigned char *)malloc(sizeof(char))) == NULL)
	{
		printf("malloc buf[0] error ...\n");
		ret = -1;
		goto err1;
	}
	
	if((data.msgs[1].buf = (unsigned char *)malloc(count * sizeof(char))) == NULL)
	{
		printf("malloc buf[1] error ...\n");
		ret = -1;
		goto err2;
	}
	
	data.msgs[0].addr = CHIP_ADDR;	//从器件地址
	data.msgs[0].len  = 1;			//数据长度
	data.msgs[0].flags = 0;			//操作方式:1为读，0为写
	data.msgs[0].buf[0] = addr;		//寄存器偏移
	
	data.msgs[1].addr = CHIP_ADDR;	//从器件地址
	data.msgs[1].len  = count;		//数据长度
	data.msgs[1].flags = 1;			//操作方式:1为读，0为写
	memset(data.msgs[1].buf,'\0',count); //初始化

	ret = ioctl(fd,I2C_RDWR,(unsigned long)&data);
	if(ret < 0)
	{
		printf("read error ...\n");
		goto err3;
	}
	
	for(i=0;i<count;i++)
		buff[i] = data.msgs[1].buf[i];
	
	return count;

err3:
	free(data.msgs[1].buf);
err2:
	free(data.msgs[0].buf);
err1:
	free(data.msgs);
err0:
	return ret;
}

