#include <stdio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>

#define CHIP			"/dev/i2c-1"
#define CHIP_ADDR		0x40

int main()
{
	int i;
	int ret;

	int fd = open(CHIP, O_RDWR);
	if (fd < 0) {
		printf("open "CHIP"failed\n");
		goto exit;
	}

	if (ioctl(fd, I2C_SLAVE_FORCE, CHIP_ADDR) < 0) {		/* SLAVE ADDR */
		printf("oictl:set slave address failed\n");
		goto close;
	}

	struct			i2c_msg msg;
	unsigned char	rddata[8];
	unsigned char	rdaddr = 0xF0;							/*  Read OFS in CHIP, SN=0xF0~0xF7 */
	unsigned char	wrbuf[3] = {0, 0, 0x3c};				/* Write OFS in CHIO */

	ret = write(fd, &rdaddr, 1);							/* Set OFS */
	if (ret > 0)
		printf("write address return: %d\n", ret);

	ret = read(fd, rddata, 8);								/* Read ID */
	if (ret > 0)
		printf("read data return:%d\n", ret);

	for (i=0; i<8; i++)
		printf("rddata: %x\n", rddata[i]);

close:
	close(fd);
exit:
	return 0;
}
