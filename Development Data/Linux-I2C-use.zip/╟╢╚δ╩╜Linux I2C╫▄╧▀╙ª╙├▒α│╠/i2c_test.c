#include <stdio.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <linux/i2c.h>
#include <string.h>

#define CHIP			"/dev/i2c-1"
#define CHIP_ADDR		0x40
#define OFS_ADDR		0x96

char wrdata[4] = {'1','2','3','4'};

int write_chip(int fd,char buff[],int addr,int count);
int read_chip(int fd,char buff[],int addr,int count);

int main(int argc,char *argv[])
{
	int ret,i;
	
	int addr = OFS_ADDR;
	unsigned char	rddata[8];

	int fd = open(CHIP, O_RDWR);
	if (fd < 0) 
	{
		printf("open failed\n");
		goto err0;
	}

	if (ioctl(fd, I2C_SLAVE_FORCE, CHIP_ADDR) < 0) 
	{		/* SLAVE ADDR */
		printf("ioctl:set slave address failed\n");
		goto err1;
	}
	
	memset(rddata,'\0',sizeof(rddata));
	ret = read_chip(fd,rddata,addr,4);
	if(ret < 0)
	{
		printf("read error ...\n");
		return -1;
	}
	printf("read origin(0x96~0x99) data is : ");
	for(i=0;i<ret;i++)
		printf("%x ",rddata[i]);
	printf("\n");

	usleep(10000);

	ret = write_chip(fd,&wrdata[0],addr,2);
	if(ret < 0)
	{
		printf("write error ...\n");
		return -1;
	}
	printf("write offset 0x96~0x97 is : %x %x \n",wrdata[0],wrdata[1]);

	usleep(10000);

	ret = write_chip(fd,&wrdata[2],addr+2,2);
	if(ret < 0)
	{
		printf("write error ...\n");
		return -1;
	}
	printf("write offset 0x98~0x99 is : %x %x \n",wrdata[2],wrdata[3]);

	usleep(10000);

	ret = read_chip(fd,rddata,addr,4);
	if(ret < 0)
	{
		printf("read error ...\n");
		return -1;
	}
	printf("read data(0x96~0x99) is : ");
	for(i=0;i<ret;i++)
		printf("%x ",rddata[i]);
	printf("\n");

err1:
	close(fd);
err0:
	return 0;
}

#define PAGE_SIZE 8 
int write_chip(int fd,char buff[],int addr,int count)
{
	int ret,i;
	static char sendbuffer[PAGE_SIZE+1];
	
	memcpy(sendbuffer+1,buff,count);
	sendbuffer[0] = addr;
	ret = write(fd,sendbuffer,count+1);
	
	return ret;
}

int read_chip(int fd,char buff[],int addr,int count)
{
	int ret;
	if(write(fd,&addr,1)!=1)		//写地址失败
		return -1;
	ret = read(fd,buff,count);
	return ret;
}

